package cubyType;


public class CubyBaseType {

}
