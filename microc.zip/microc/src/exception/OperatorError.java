package exception;

public class OperatorError extends Exception {
    public OperatorError(String msg){
        super(msg);
    }
}
