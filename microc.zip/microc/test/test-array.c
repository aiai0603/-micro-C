Void main(Int n) {
  
    Int a[6];
    a[0]=1222;
    a[3] = 2;
    Int bb;
    bb=1;

    print("%d",a);
    return 0;

}

