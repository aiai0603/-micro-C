Void main() {
  
  

    print("%d",(int)12.5);
    print("%d",(int)'3');

    print("%c",(char)2);

    print("%f",(float)12);


}

