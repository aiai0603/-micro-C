Void main(Int n) {
  
    Char a;
    a = '3';
    print("%c",a);

}

