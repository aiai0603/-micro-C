Void main(Int n) {
    Int i;
    i=0;
   do {
        print("%d",i);
        i= i+1;
   }  
   until(i>n);



}

