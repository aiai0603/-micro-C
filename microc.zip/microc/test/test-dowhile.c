Void main(Int n) {
    Int i;
    i=0;
   do {
        print("%d",i);
        n=n-1;
   }  
   while(i<n);



}

