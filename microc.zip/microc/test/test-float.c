Void main(Int n) {
   Float a;
   a = 1.375;
   Float b;
   b = 1.5;
   print("%f",(a+b));

}

