Void main(Int n) {
    Int i;
    i=0;
   
    for( i = 0 ; i < n;  i = i + 1){
        i=i+1;
        print("%d",i);
    }

   print("%d",i);



}

