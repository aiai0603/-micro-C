Void main(Int n) {
  
    Int a[10];
    a[3] =1;
    a[4] =2;
    a[5] =3;
    a[6] =4;
    a[7] =1;
    Int i;
    
    for i in (a[3],a[7])
    {
        print("%d",i);
    }




}

