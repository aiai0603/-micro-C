Void main(Int n) {
  
    Int i;
    for i in (3,7)
    {
        print("%d",i);
    }




}

