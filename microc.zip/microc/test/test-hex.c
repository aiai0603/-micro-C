Void main(Int n) {
  
    Int a;
    a = createI("F122",16);

    print(16,a);

    Int b;
    b = createI("1010",2);

    print(2,b);

}

