/*
bug:全局变量不能附初值
Int  i =1;
*/
Void main(Int n) {
  
    Int a = 7;
    Char b = 'c';
    String s = "12121212";
    Float f = 12.32;
    
    //print("%d",i);
    print("%d",a);
    print("%c",b);
    println(s);
    print("%f",f);

}

