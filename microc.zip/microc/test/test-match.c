Void main(Int n) {
    match n with
    | 2 -> print("%d",n);
    | 3 ->print("%d",n+1);
    | _ ->print("%d",2);
}

