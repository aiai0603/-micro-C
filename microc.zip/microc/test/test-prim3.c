Void main(Int n) {
    Int i;
    i =  n>2?12:21;
    print("%d",i);
    
}

