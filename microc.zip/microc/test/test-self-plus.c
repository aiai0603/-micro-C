Void main(Int n) {
  
    Int a;
    a=10;
    a+=n;
    print("%d",a);
    a=10;
    a-=n;
    print("%d",a);
    a=10;
    a*=n;
    print("%d",a);
    a=10;
    a/=n;
    print("%d",a);
    a=10;
    a%=n;
    print("%d",a);

}

