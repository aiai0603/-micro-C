Void main(Int n) {
  
    String a;

    a="test1";
  
    println(a);
   
    String b;

    b="mytest2";
    println(a);
    println(b);
    

    Int c;
    c=12;
    b="mytest2";
    println(a);
    println(b);
    print("%d",c);
 


}

