Struct test {
        Int a;
        String b;
} ;
    
Void main(Int n) {
  Struct test t;
 

}

