Void main(Int n) {
  

    switch( n ){
        case 1 :  print("%d",n);
        case 2 :  print("%d",n+1);
        default : print("%d",2);
    }
    print("%d",n);

}

