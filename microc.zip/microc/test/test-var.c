Void main(Int n) {
    Char Aa;
    Int Asa[10];

}

